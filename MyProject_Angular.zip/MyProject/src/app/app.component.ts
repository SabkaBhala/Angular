// import { Component } from '@angular/core';

// @Component({
//   selector: 's1',
//   templateUrl: './app.component.html',
//   styles:['h1{color:black}','h2{color:red}','h3{color:blue}']
// })
// export class AppComponent {
//   title = 'MyProject';
//   id: number=101;

//   name: String="Himanshu";
//   isAvailable: String="Yes";
// }


import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
 
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;
 
  constructor(private formBuilder: FormBuilder) { }
 
  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      username: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }
 
  get f() {
    return this.registerForm.controls;
  }
 
  onSubmit() {
    this.submitted = true;
 
    if (this.registerForm.invalid) {
      return;
    }
 
    console.log('email=' + this.f.email.value);
    console.log('username=' + this.f.username.value);
    console.log('password=' + this.f.password.value);
  }
}
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  login: String="admin";
  password: String="admin";
 
  checklogin(){
    alert("hello"+this.login)
  }

  constructor() { }

  ngOnInit() {
  }

}

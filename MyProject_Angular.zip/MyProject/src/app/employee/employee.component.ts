import { Component, OnInit } from '@angular/core';
import { getTypeNameForDebugging } from '@angular/core/src/change_detection/differs/iterable_differs';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  title = 'MyProject';
  id: number=101;
  name: String="Himanshu Kaushik (HK)";
  isAvailable: String="Yes";

  imagePath: String="assets/images/dcheck.jpg";
  empList: any=[
    {eid:101, name:'Himanshu', job:'Developer'},
    {eid:102, name:'Hihu', job:'Deper'},
    {eid:103, name:'Hnshu', job:'Dper'},
    {eid:104, name:'Hmanshu', job:'D'}
  ];
  empNo:number=4;

  constructor() { }

  ngOnInit() {
    //this.hello();
  }

  getName(){
    //alert("Hello");
      alert("Hello! "+this.name)
    }
  }

// import { BrowserModule } from '@angular/platform-browser';
// import { NgModule } from '@angular/core';
// import {FormsModule, ReactiveFormsModule } from '@angular/forms';

// import { AppComponent } from './app.component';
// import { EmployeeComponent } from './employee/employee.component';
// import { LoginComponent } from './login/login.component';
// import { MyFormComponent } from './my-form/my-form.component';

// @NgModule({
//   declarations: [
//     AppComponent,
//     EmployeeComponent,
//     LoginComponent,
//     MyFormComponent
//   ],
//   imports: [
//     BrowserModule,FormsModule
//   ],
//   providers: [],
//   // bootstrap: [AppComponent,EmployeeComponent,LoginComponent]
//   bootstrap: [LoginComponent, MyFormComponent]
// })
// export class AppModule { }


import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
 
import { AppComponent } from './app.component';
 
@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
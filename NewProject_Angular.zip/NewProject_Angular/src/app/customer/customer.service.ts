import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor() {}
  getCustomer(){
    return new Customer(101, 'king');
  }  
}

export class Customer{
  constructor(cid,cname){
    this.cid=cid;
    this.cname=cname;
  }
  cid:number;
  cname:string;
}
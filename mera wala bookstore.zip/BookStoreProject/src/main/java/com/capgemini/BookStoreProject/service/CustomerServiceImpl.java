package com.capgemini.BookStoreProject.service;



@org.springframework.stereotype.Service
public class CustomerServiceImpl implements ICustomerService {

	
	

}

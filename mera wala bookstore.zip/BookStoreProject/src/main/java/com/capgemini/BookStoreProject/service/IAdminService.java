package com.capgemini.BookStoreProject.service;

import java.util.List;

import org.springframework.stereotype.Service;

/*import com.capgemini.BookStoreProject.beans.Book;
*//*import com.capgemini.BookStoreProject.beans.Category;
import com.capgemini.BookStoreProject.beans.Orders;*/
import com.capgemini.BookStoreProject.beans.RegisterCustomer;

@Service
public interface IAdminService {

	public RegisterCustomer registerCustomer(RegisterCustomer customer);

	public List<RegisterCustomer> listAllCutomers();

	List<RegisterCustomer> editCustomer(RegisterCustomer customer);

	List<RegisterCustomer> deleteCustomer(int customerId); 
}

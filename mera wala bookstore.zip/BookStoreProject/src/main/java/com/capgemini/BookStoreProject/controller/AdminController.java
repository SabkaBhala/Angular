package com.capgemini.BookStoreProject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/*import com.capgemini.BookStoreProject.beans.Book;
*//*import com.capgemini.BookStoreProject.beans.Category;
	import com.capgemini.BookStoreProject.beans.Orders;*/
import com.capgemini.BookStoreProject.beans.RegisterCustomer;
/*import com.capgemini.BookStoreProject.beans.Review;*/
import com.capgemini.BookStoreProject.beans.Users;
/*+*/
import com.capgemini.BookStoreProject.service.IAdminService;

@RestController
public class AdminController {

	@Autowired
	IAdminService adminService;

	@RequestMapping(value = "/showAllCustomers", method = RequestMethod.GET)
	public List<RegisterCustomer> showAllCustomers() {
		return adminService.listAllCutomers();
	}

	@RequestMapping(value = "/editCustomer", method = RequestMethod.PUT)
	public List<RegisterCustomer> updateCustomer(@RequestBody RegisterCustomer customer) {
		return adminService.editCustomer(customer);

	}

	@RequestMapping(value = "/deleteCustomer/{customerId}", method = RequestMethod.GET)
	public List<RegisterCustomer> deleteCustomer(@PathVariable int customerId) {
		return adminService.deleteCustomer(customerId);

	}
}

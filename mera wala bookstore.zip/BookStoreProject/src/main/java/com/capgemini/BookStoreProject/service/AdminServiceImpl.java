package com.capgemini.BookStoreProject.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/*import com.capgemini.BookStoreProject.beans.Book;
*//*import com.capgemini.BookStoreProject.beans.Category;
import com.capgemini.BookStoreProject.beans.Orders;*/
import com.capgemini.BookStoreProject.beans.RegisterCustomer;
/*import com.capgemini.BookStoreProject.beans.Review;
*/import com.capgemini.BookStoreProject.beans.Users;
/*import com.capgemini.BookStoreProject.dao.IBookDAO;*/
import com.capgemini.BookStoreProject.dao.ICustomerDAO;
/*import com.capgemini.BookStoreProject.dao.ICategoryDAO;
import com.capgemini.BookStoreProject.dao.IOrdersDAO;
import com.capgemini.BookStoreProject.dao.IReviewDao;
*/import com.capgemini.BookStoreProject.dao.IUserDAO;
/*import com.capgemini.BookStoreProject.exceptions.BookAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.BookDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.BookIdDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.CategoryDoesNotExistsException;
import com.capgemini.BookStoreProject.exceptions.CategoryIdAlreadyExistsException;
import com.capgemini.BookStoreProject.exceptions.CustomerAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.CustomerDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.NoBooksFoundException;
import com.capgemini.BookStoreProject.exceptions.OrderDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.ReviewDoesNotExistException;
import com.capgemini.BookStoreProject.exceptions.UserAlreadyExistException;
import com.capgemini.BookStoreProject.exceptions.UserDoesNotExistException;*/

@Service
public class AdminServiceImpl implements IAdminService{
	

	@Autowired
	IUserDAO userDAO;
	
	@Autowired
	ICustomerDAO customerDAO;
	
		

	@Override
	public RegisterCustomer registerCustomer(RegisterCustomer customer)  {
		String phonenumber=customer.getPhonenumber();
		List<RegisterCustomer> customerList=listAllCutomers();
		for(RegisterCustomer list:customerList)
		{
			if(phonenumber.equals(list.getPhonenumber()))
				System.out.println("This customer's Phone number is already exist");;
		}
			customerDAO.save(customer);
			return customer;
	}

	
		
	@Override
	public List<RegisterCustomer> listAllCutomers() {
		
		return customerDAO.findAll();
	}

	
	
	@Override
	public List<RegisterCustomer> editCustomer(RegisterCustomer customer) {
		if(customerDAO.existsById(customer.getCustomerId())) {
			customerDAO.saveAndFlush(customer);
			return customerDAO.findAll();
		}
		else
			return null;
	}

	@Override
	public List<RegisterCustomer> deleteCustomer(int customerId){
		
		if(customerDAO.existsById(customerId))
		{
			customerDAO.deleteById(customerId);
			return customerDAO.findAll();
		}
		
		else
			return null;
	}
	
}

package com.capgemini.BookStoreProject.service;
import org.springframework.stereotype.Service;

@Service
public interface ICustomerService { }

import { Component, OnInit } from '@angular/core';
import { Employee } from './employee';
import { EmployeeService } from './employee.service';
//import { empData } from './employee.data';

@Component({
	selector:'emp-data',
	//template:`Employee Id:- {{emp.empid}}<br>Employee Name:- {{emp.ename}}<br>Employee salary:- {{emp.salary}}`,
	templateUrl:'./employee.component.html',
	styles:[]
})

export class EmployeeComponent implements OnInit
{
		//This is how we work with json object.
	//emp={'empid':101,'ename':'AjayDevgan','salary':30000};

	//emp:Employee=new Employee(999,'Rohit',5000);     //This is how we work by creating an object and using its fields by making a class employee.ts in app folder.
	
//This is how to show the data in table format
	//emp:Employee[]=[new Employee(999,'Rohit',5000),
	//		new Employee(998,'Rohi',5000),
	//		new Employee(997,'Roh',5000),
	//		new Employee(996,'Ro',5000),
	//		new Employee(995,'R',5000)
	//	       ];
	
		//emp:Employee[]=empData;
		//public constructor( private employeeService){}	

	emp:Employee[];
	e:Employee=new Employee(0,null,0);
	public constructor( private employeeService:EmployeeService){}
	
	ngOnInit(){}
	public getEmployees():void
	{
		this.employeeService.getEmployees().subscribe(data=>{this.emp=data});

	}
	public getEmployee():void
	{
		this.employeeService.getEmployee(this.e.empid).subscribe(data=>{this.e=data});
	}
	public addEmployee():void
	{
		this.employeeService.addEmployee(this.e).subscribe();
	}
	public modEmployee():void
	{
		this.employeeService.modEmployee(this.e).subscribe();
	}
	public delEmployee():void
	{
		this.employeeService.delEmployee(this.e.empid).subscribe();
	}
}
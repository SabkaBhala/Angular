import { Component, Input , Output , EventEmitter} from '@angular/core';

@Component({
	selector:'child-tag',
	template: '<h2>Child Displays </h2>{{childData}}<br><button (click)="sendMessageToParent()">click</button>',	
	styles:[]
})
export class BComponent
{
	@Input() childData:String;
	@Output() cEvent= new EventEmitter();
	public sendMessageToParent(){
		this.cEvent.emit('Hello Parent');
	}
}
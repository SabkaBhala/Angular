import { Component } from '@angular/core';


@Component({
 
 	selector: 'myTag',
 
 	templateUrl: './app.component.html',

 	styles: ['h1{text-align:center;color:red}']

})

export class AppComponent 
{
 
	 name:string='saurabh';
	
}
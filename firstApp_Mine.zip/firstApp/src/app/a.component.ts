import { Component } from '@angular/core';
@Component({
	selector:'parent-tag',
	template: 'Message from child {{childMessage}}<br><child-tag [childData]="message" (cEvent)="childMessage=$event"></child-tag>',	
	styles:[]
})
export class AComponent
{
	message:string="Hello Child";
	childMessage:string;
}
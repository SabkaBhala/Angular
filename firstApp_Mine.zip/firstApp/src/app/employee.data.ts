import { Employee } from './employee';
export const empData:Employee[]=[new Employee(999,'Rohit',5000),
			new Employee(998,'Rohi',5000),
			new Employee(997,'Roh',4000),
			new Employee(996,'Ro',3000),
			new Employee(995,'R',2000)
		        ];